'use strict';

app.controller('shoppingListController',shoppingListController);

shoppingListController.$inject = ["$scope", "$http", "$window", "$q", "$state"];

function shoppingListController($scope, $http, $window, $q, $state) {
    
    $scope.items = [];
    $scope.items[0] = {id: 1, desc: "maslo 1 kostka" , is_done: false};
    $scope.items[1] = {id: 2, desc: "cukier 1 kg" , is_done: true};
    $scope.items[2] = {id: 3, desc: "cukier 1 kg" , is_done: true};
    $scope.items[3] = {id: 4, desc: "cukier 1 kg" , is_done: true};
    $scope.items[4] = {id: 5, desc: "cukier 1 kg" , is_done: true};
    $scope.items[5] = {id: 6, desc: "cukier 1 kg" , is_done: true};
    
    $scope.toggleItem = function(item){
        var element = angular.element( document.querySelector( '#item_label_' + item.id ) )[0];
        
        if (element.classList.contains('item_label_toggled')){
            element.classList.remove('item_label_toggled');  
            item.is_done = false;
        }
        else{
            element.classList.add('item_label_toggled');   
            item.is_done = true;
        }
    }
    
    $scope.addItem = function(item){
        
    }
    
    $scope.removeItem = function(item){
        console.log(item);
//        item.clear();
    }
    
    $scope.clearAll = function(){
        $('#shopping_list').empty();
    }
}