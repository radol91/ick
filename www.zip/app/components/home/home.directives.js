// angular.module('kuchnia4U')
//     .directive('homeBlock', function() {
//         return {
//             templateUrl: '/app/components/home/views/homeblock.view.html'
//         };
//     });