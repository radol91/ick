 angular.module('kuchnia4U')
     .directive('categoryMenu', function() {
         return {
             templateUrl: '/app/components/home/category_menu.view.html'
         };
     });