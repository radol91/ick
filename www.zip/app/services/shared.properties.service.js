'use strict';

angular.module('kuchnia4U.sharedPropertiesService', []).factory('sharedPropertiesService', sharedPropertiesService);

categoryService.$inject = ['$rootScope'];

function sharedPropertiesService($rootScope) {

	return sharedPropertiesService;
};
